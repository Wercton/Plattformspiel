from data.objetos.Astronaut import Astronaut
from data.objetos.Botao import Botao
from data.objetos.Cometa import Cometa
from data.objetos.Estrela import Star
from data.objetos.Mob import Mob, Atencao
from data.objetos.Nuvem import Nuvem
from data.objetos.Plataforma import Plataforma
from data.objetos.Poder import Poder
from data.objetos.Spritesheet import Spritesheet