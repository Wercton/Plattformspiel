from data.configuracoes import *
from data.interface import Interface_Game
from data.jogo_classe import Game
from data.personagem import Jogador